from django.contrib import admin
from .models import  Notice, Image

# Register your models here.

admin.site.register(Notice)
admin.site.register(Image)
