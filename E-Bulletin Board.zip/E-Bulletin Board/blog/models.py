from django.db import models
from django.utils import timezone
from django.urls import reverse
from django.contrib.auth.models import User

# Create your models here.

class Notice(models.Model):
    author = models.ForeignKey('auth.User', on_delete=models.CASCADE)
    title = models.CharField(max_length=200, default="Notice")
    text1 = models.TextField(default="Notice", blank="True")
    text2 = models.TextField(default="Notice", blank="True")
    text3 = models.TextField(default="Notice", blank="True")
    text4 = models.TextField(default="Notice", blank="True")
    text5 = models.TextField(default="Notice", blank="True")
    type = models.CharField(max_length=200, default="Text")
    create_date = models.DateTimeField(default=timezone.now)
    notice_number = models.CharField(max_length= 10, default="one")

    def __str__(self):
        return self.title

class Image(models.Model):
    author = models.ForeignKey('auth.User', on_delete=models.CASCADE)
    create_date = models.DateTimeField(default=timezone.now)
    image1 = models.FileField(upload_to="post", blank= True)
    notice_number = models.CharField(max_length= 10, default="two")
    type = models.CharField(max_length=200, default="Image")


    def __str__(self):
        return self.notice_number
