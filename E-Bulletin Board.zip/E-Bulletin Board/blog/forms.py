from django import forms
from .models import Notice, Image
from django.contrib.auth.models import User


class NoticeForm(forms.ModelForm):
    class Meta():
        model = Notice
        fields =  ('title','text1','text2','text3','text4','text5','notice_number')

class INoticeForm(forms.ModelForm):
    class Meta():
        model = Image
        fields =  ('image1',)


class LoginForm(forms.Form):
    username = forms.CharField(max_length=30)
    password = forms.CharField(max_length=30,widget=forms.PasswordInput())
