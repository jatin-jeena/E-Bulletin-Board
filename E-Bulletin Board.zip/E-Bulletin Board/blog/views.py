from django.shortcuts import render,get_object_or_404,redirect
from django.urls import reverse
from django import forms
from .forms import NoticeForm, LoginForm, INoticeForm
from .models import Notice, Image
from django.core.exceptions import ValidationError
from django.contrib.auth import authenticate, login, logout
from django.http import HttpResponse, HttpResponseRedirect
from django.contrib.auth.decorators import login_required
from django.db.models import Q
from itertools import chain
# Create your views here.


def home(request):
    alltext = Notice.objects.all().order_by('-create_date')
    allimagenotice = Image.objects.all().order_by('-create_date')
    all = list(chain(alltext, allimagenotice))
    return render(request,"home.html",{'all':all})


def noticeCreate(request):
    if request.method == "POST":
        noticecreateform = NoticeForm(request.POST)
        if noticecreateform.is_valid() :
            postfinal = noticecreateform.save(commit=False)
            postfinal.author = request.user
            postfinal.save()
            return redirect("homepage")
    else:
        noticecreateform = NoticeForm()
        return render(request,"noticecreateform.html",{'noticecreateform':noticecreateform})

def inoticeCreate(request):
    if request.method == "POST":
        noticecreateform = INoticeForm(request.POST)
        if noticecreateform.is_valid() :
            postfinal = noticecreateform.save(commit=False)
            postfinal.author = request.user
            postfinal.image1 = request.FILES.get('image1')
            postfinal.save()
            return redirect("homepage")
    else:
        noticecreateform = INoticeForm()
        return render(request,"inoticecreateform.html",{'noticecreateform':noticecreateform})

def user_login(request):
    if request.method == 'POST':
        username = request.POST.get("username")
        password = request.POST.get("password")

        user = authenticate(username = username , password= password)
        if user:
            if user.is_active:
                login(request, user)
                return HttpResponseRedirect(reverse('homepage'))
            else:
                return HttpResponse("user not active")
        else:
            raise ValidationError('User does not exist')
    else:
        loginform = LoginForm()
        return render(request,"login.html", {'loginform':loginform})


def user_logout(request):
    logout(request)
    return HttpResponseRedirect(reverse("homepage"))
